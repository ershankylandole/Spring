package com.springdemo.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.springdemo.dao.CustomerDao;
import com.springdemo.entity.Customer;
import com.springdemo.service.CustomerService;

@Controller
@RequestMapping("/customer")
public class CustomerController {

	@Autowired
	private CustomerService customerService;
	
	@GetMapping("/list")
	public String getCustomer(Model model) {
		
		List<Customer> customer = customerService.getCustomers();
		
		model.addAttribute("customer",customer);
		
		return "list-customers";
	}
	
	@GetMapping("/showForAddCustomer")
	public String showForAddCustomer(Model model) {
		
		Customer customer = new Customer();
		
		model.addAttribute("customer" , customer);
		
		return "add-customer";
	}
	
	
	@RequestMapping(value = "/saveCustomer", method = RequestMethod.POST)
	public String saveCustomer(@ModelAttribute("customer") Customer customer) {
		
	
			customerService.saveCustomer(customer);
		
		return "redirect:/customer/list";
	}
	
	
	
	@GetMapping("/showFormforupdate/{id}")
	public String update(@PathVariable("id") int id,Model model) {
		
		Customer customer = customerService.getCustomer(id);
		
		model.addAttribute("ucustomer",customer);
		
		return "update-customer";
	}
	
	@RequestMapping(value = "/updateCustomer", method = RequestMethod.POST)
	public String updateCustomer(@ModelAttribute("ucustomer") Customer customer) {
		
	
			customerService.updateCustomer(customer);
		
		return "redirect:/customer/list";
	}
	
}
