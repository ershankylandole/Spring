package com.springdemo.service;

import java.util.List;

import com.springdemo.entity.Customer;

public interface CustomerService {
	
	List<Customer> getCustomers();
	boolean saveCustomer(Customer customer);
	Customer getCustomer(int id);
	Customer updateCustomer(Customer customer);

}
