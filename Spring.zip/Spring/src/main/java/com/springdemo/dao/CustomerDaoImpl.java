package com.springdemo.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springdemo.entity.Customer;

@Repository
public class CustomerDaoImpl implements CustomerDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public List<Customer> getCustomers() {
		
		Session session = sessionFactory.openSession();
		
		Query<Customer> query = session.createQuery("From Customer order by lastName",Customer.class);
		
		List<Customer> customer = query.getResultList();
		
		return customer;
	}

	@Override
	public boolean saveCustomer(Customer customer) {
		Session session = sessionFactory.openSession();
		
		return (Integer)session.save(customer) > 0;
		 
	}

	@Override
	public Customer getCustomer(int id) {
		
		Session session = sessionFactory.openSession();
		
		Customer customer = session.get(Customer.class, id);
		return customer;
	}

	@Override
	public Customer updateCustomer(Customer customer) {
		
		Session session = sessionFactory.openSession();
		
		//Customer customer = session.get(Customer.class, id);
		
		session.merge(customer);
		
		return customer;
	}
	
	

}
