package com.springdemo.dao;

import java.util.List;

import com.springdemo.entity.Customer;

public interface CustomerDao {

	List<Customer> getCustomers();
	boolean saveCustomer(Customer customer);
	Customer getCustomer(int id);
	Customer updateCustomer(Customer customer);
}
